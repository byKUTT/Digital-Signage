=== Screens byKUTT ===
Contributors: bykutt
Author: byKUTT
Tags: digital signage, kiosk, cms, screens, display
Requires at least: 5.9
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 4.5.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Turn WordPress into a full digital signage (CMS) platform for managing content on TVs, tablets and kiosks.

== Description ==

Screens byKUTT gives you:

* **Channels** — named playlists of content ("Lobby Menu", "Cafeteria Board") assignable to one or more screens.
* **Screens** — registered displays with orientation, 0°/90°/180°/270° content rotation, optional short player URLs, location and live online/offline status.
* **Slides** — images, videos, webpages (iframe), custom HTML/CSS, RSS/Atom tickers, weather, live clock, PDF/Google Slides embeds, social embeds and multi-image sliding carousels, with per-slide duration and channel-level transitions.
* **Schedules** — recurring day-of-week/time rules and one-off date overrides per screen, plus priority/emergency channels that interrupt normal rotation everywhere instantly.
* **Fullscreen player** — a chrome-less, auto-fullscreen frontend at `/signage/play/{token}/` that polls for updates, preloads the next slide, keeps playing from a local cache when offline, and supports multi-zone layouts (main + ticker + corner clock, split screen, grid).
* **Admin dashboard** — live screen status, pairing flow, bulk channel assignment, drag-and-drop playlist reordering, a weekly calendar view, proof-of-play analytics with CSV export, JSON import/export, and remote refresh/reload commands.
* **REST API** (`/wp-json/ds/v1/...`) for the player and for external kiosk hardware such as a Raspberry Pi running a browser in kiosk mode.
* A shared **Digital Signage Team** and **Signage Manager** role for people who need access to all signage content and settings without full WordPress administrator access.
* **Multi-display controllers** — one generic Linux or Windows PC can drive several connected displays, with a different Screen, channel, schedule and rotation on every output.
* **Fleet management** — grouped controller health, detailed telemetry, output mapping, command history, verified signage updates, OS update commands and remote kiosk/desktop controls.
* **Spotify Connect control** — an optional controller-scoped panel for authenticated Spotify Premium users to search songs and control an existing Spotify playback device. A Spotify User role can be limited to explicitly assigned controllers.
* **Licensed background music** — a group-scoped local audio library with searchable styles, playlists, per-controller output assignment, and automatic 1.5-second ducking around slide audio.

== External services ==

The optional Spotify panel connects to Spotify Accounts (`accounts.spotify.com`) for OAuth authorization and the Spotify Web API (`api.spotify.com`) for device discovery, search, and user-triggered playback controls. Enabling it sends the connected Spotify account and playback requests to Spotify under Spotify's Developer Terms and Privacy Policy. It is disabled until a site administrator supplies Spotify application credentials and a user explicitly connects an account. Digital Signage does not synchronize Spotify audio with signage content and does not use Spotify for non-interactive broadcasting.

The Music page contains an ordinary link to Pixabay Music (`pixabay.com/music/`) as one place to browse free audio. The plugin does not call a Pixabay API or send WordPress, group, controller, or user data to Pixabay. Audio is downloaded by the user and uploaded to their own WordPress media storage. Users remain responsible for checking and recording the license that applies to each track and intended commercial use.

== Installation ==

1. Upload the `digital-signage` folder to `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to **Digital Signage → Settings** to set global slide durations, transitions, poll/heartbeat intervals and time zone.
4. Go to **Digital Signage → Pair a Screen**, open the generated player URL on the target TV/tablet/browser, then either scan the QR code it displays with your phone or enter the code manually to link the device.
5. Create a **Channel**, add **Slides** to it, then assign the channel to a **Screen** (or schedule it via **Schedules**).

For a private VIDAA 9 TV player, open `https://your-site.example/signage/tv/` in the TV browser. The launcher creates a persistent TV identity and shows a six-character pairing code. Pair it in WordPress, bookmark the launcher, and use any Browser/App Auto Start option provided by the TV. Consumer VIDAA firmware may still require opening the bookmark after a cold boot. Press **OK** once if the browser asks to start fullscreen playback. For widest TV compatibility, use MP4 video encoded as H.264 with AAC audio; playback starts muted because TV browsers enforce autoplay rules.

== Architecture notes ==

* Channels, Screens, Slides and Schedules are custom post types (`ds_channel`, `ds_screen`, `ds_slide`, `ds_schedule`) used purely as a storage layer — there is no native WordPress post-editor screen for any of them (`show_ui => false`). Every list, create and edit screen is a fully custom admin UI (`includes/class-ds-admin.php` + `admin/views/*.php`) built from scratch, writing through `includes/class-ds-crud.php` and gated by a single `manage_digital_signage` capability rather than WordPress's per-post-type meta capabilities.
* High-write, append-only data — heartbeats, the proof-of-play log, and pairing codes — live in three custom `$wpdb` tables (`ds_heartbeats`, `ds_proof_of_play`, `ds_pairing_codes`) created on activation via `dbDelta()`.
* Scheduling housekeeping (expiring pairing codes, trimming the proof-of-play log, clearing stale manual overrides) runs on **WP-Cron**.
* The wp-admin Screens dashboard uses WordPress's own **Heartbeat API** to live-refresh status badges while an admin has the page open.
* The frontend player never touches PHP after first load — it talks entirely to the **REST API**, so it works equally well embedded in a WebView or a plain browser tab.

== Changelog ==

= 4.5.0 =
* Introduced the Screens byKUTT identity and rebuilt the frontend dashboard in the new deep-forest visual system.
* Added group-scoped licensed music uploads, searchable track libraries, playlists, and per-controller audio-output assignment.
* Added automatic 1.5-second background-music ducking while a signage video plays sound, with automatic restoration afterwards.

= 4.4.0 =
* Added controller-scoped Spotify Connect controls with a restricted Spotify User role.
* Rebuilt the template library with 32 landscape and portrait starter designs.
* Refined the Vellum workspace, portal controls, pairing, and reconnecting screens.
* Repaired passwordless controller actions with explicit sudo command signatures and a real installation check.
* Simplified deletion to one clear confirmation.

= 4.3.0 =
* Added QR-assisted controller binding, unassigned-display recovery, and no-channel reconnection through the authenticated frontend portal.
* Rebuilt the Vellum workflow as a full-screen editor with save-and-close, personal saved files, and four built-in templates available to every group.
* Added a site-administrator remote diagnostics console with fixed read-only checks and audited command output.
* Made Ubuntu Git updates resilient to managed-source drift, skipped unnecessary package downloads during upgrades, and returned the real failing stage and recent service log.

= 4.2.0 =
* Added the bundled Vellum designer with landscape, portrait, and square signage canvases, saved group designs, preview rendering, and one-click channel publishing.
* Added a separate `bin/update-vellum.sh` command for refreshing the locally bundled editor from the official Vellum repository.
* Slides can now be renamed and edited from the frontend, select or upload WordPress media, override duration, and play videos to the end by default.
* Slide deletion is immediate and no longer requires a typed verification phrase.
* Moved display sleep scheduling into each controller's settings and replaced schedule text fields with native 24-hour time pickers.
* Added searchable IANA city timezones and removed the unsupported one-off display power test.

= 4.1.2 =
* Fixed first-use Group access denied failures by creating a personal workspace automatically.
* Controllers stay private and hidden until their on-screen code is paired by a signed-in user.
* Paired controllers and generated display screens now retain their owner and workspace assignment.
* Added branded frontend login and registration screens plus a Screen Manager admin-bar shortcut.
* Set screens.kutt.ee as the default Ubuntu and Raspberry Pi controller website.

= 4.1.1 =
* Fixed WP_Post conversion warnings in frontend access filtering.
* Added group-scoped screens, controllers, channels, schedules, settings, media, and Screen Manager accounts.
* Completed the frontend manager with creation, editing, pairing, telemetry, logs, calendar schedules, and verified deletion.
* Software updates now show an Updating screen on every output, report the final result, and reboot after success.
* Sleep schedules now use the synchronized WordPress server clock and server timezone, with actionable DPMS errors in logs.
* Standardized portal schedule and activity timestamps on 24-hour server time.

= 4.0.0 =
* Added the authenticated `/signage-manager/` frontend portal with a simplified overview, screens, channels, controllers, and people experience.
* Added per-screen and per-channel ownership/sharing by WordPress user email; non-administrators see only their own or shared signage.
* Added controller display sleep schedules that power monitors off and on while Ubuntu remains awake.
* Added verified Switch URL migration, which moves a controller to another WordPress installation and reboots it automatically.
* WordPress-triggered software updates now reboot automatically after a successful update while preserving device settings and identity.
* Ubuntu privileged device actions use a narrowly allowlisted passwordless helper; no device password is stored in WordPress.

= 3.4.0 =
* Fixed Ubuntu controller updates from WordPress by queuing the configured Git updater without requiring an unrelated GitHub Release asset.
* Ubuntu installation now verifies narrow passwordless sudo access for the signage helper automatically.
* Cursor hiding now combines an invisible X cursor with immediate unclutter enforcement and reports its state in telemetry.
* Simplified controller, screen, channel, and schedule pages by prioritizing everyday actions and moving technical controls into accessible advanced sections.
* Controller command failures now explain the actual recoverable problem instead of showing a generic queue error.

= 3.3.0 =
* Ubuntu launches Chrome once per assigned output at boot without window detection or automatic browser-health relaunch loops.
* Added persistent Start Kiosk Screens and Close Screens / Show Desktop controls to the WordPress controller page.
* Kiosk mode hides the mouse cursor while desktop mode restores it for local setup work.
* Disabled automatic blanking, locking, suspend, and hibernation controller-wide; no automatic reboot or watchdog was added.
* WordPress-triggered signage updates now run through a non-blocking system service and report their latest result while preserving settings.

= 3.2.2 =
* Fixed Chrome kiosk windows repeatedly opening and closing when the initial launcher process exits after handing off a live browser window.
* Ubuntu controllers now track the actual X11 window for health and close/restart only windows that disappear or change assignment.
* The kiosk cursor is hidden automatically and Chrome sign-in, sync, profiles, password prompts, autofill, and GNOME keyring access are disabled.

= 3.2.1 =
* Ubuntu kiosks now start Google Chrome automatically from the real GDM graphical session on every boot.
* One isolated Chrome kiosk window is positioned on every connected XRandR output for independent screen/channel playback.
* Replaced the unreliable early system service and hard-coded DISPLAY value with XDG session autostart and process-only recovery.
* Existing controller identity, site, output assignments, Git settings, and other persisted configuration remain intact during update.

= 3.2.0 =
* Added an Ubuntu Desktop controller using the installed Firefox instead of unavailable firefox-esr packages.
* Added independent per-channel playback for every connected XRandR monitor with stable connector assignments.
* Added a one-command, fast-forward Git updater that preserves controller identity and settings.
* Added safe migration away from the Raspberry Pi tty1 service that caused a black screen on Ubuntu.
* Firefox and controller processes recover automatically without any scheduled or watchdog computer reboot.

= 3.1.0 =
* Fixed public GitHub Release updates by validating complete release assets and falling back to the published SHA256SUMS manifest when GitHub does not expose asset digests.
* Added controller fleet updating from Digital Signage > Updates: update selected controllers, reinstall a selected current controller, or update every outdated Linux/Windows controller.
* Added queued/offline delivery, duplicate update prevention, downgrade protection and per-controller update command status.
* Improved release diagnostics so a missing GitHub Release is distinguished from a branch-only ZIP, incomplete assets, rate limiting and checksum failures.

= 3.0.1 =
* Added a one-click Windows controller installer that asks only for the WordPress domain, requests administrator permission, starts immediately and can be re-run to update/reinstall while preserving the controller identity.

= 3.0.0 =
* Added Linux and Windows multi-display controllers. Every connected output receives an independent Screen and isolated browser player while the admin groups them under one controller computer.
* Added controller pairing, authenticated heartbeats, display reconciliation, detailed telemetry, durable remote commands and command acknowledgements.
* Added verified GitHub Release updates for the WordPress plugin and device software, pinned to the project repository and protected by SHA-256 release digests.
* Added configurable Linux suspend and hardware RTC wake schedules with capability reporting and a two-minute wake test.
* Added controller fleet, controller detail and Updates pages, plus controller/output links on managed Screens.

= 2.11.0 =
* Added an administrator-managed Digital Signage Team. Selected WordPress users share all channels, screens, slides, schedules, analytics and signage settings without receiving unrelated administrator permissions.
* Added per-screen 0°, 90°, 180° and 270° browser content rotation with live updates on every player type.
* Added opt-in stable six-character player URLs under `/s/{code}/`, with the private long token URL retained as a fallback.

= 2.10.1 =
* Fixed `/signage/tv/` showing the WordPress 404 page when a host did not flush permalink rewrite rules after updating the plugin. The TV launcher now also recognizes its request path directly.

= 2.10.0 =
* Added a private VIDAA 9 smart-TV launcher at `/signage/tv/` with persistent device identity, rotating six-character pairing, automatic reconnect and a long-press OK reset.
* Added VIDAA/Hisense remote OK handling, TV-scale focus styling, fullscreen activation, resume recovery and distinct heartbeat reporting.
* Documented VIDAA browser setup, power-on limitations and H.264/AAC media compatibility.

= 2.9.7 =
* Optimized Infinite Slider at the JS/CSS layer: repeated cached image copies no longer register redundant load/measurement work, images decode asynchronously, and duplicate sequences are hidden from accessibility traversal.
* Removed per-image 3D/backface layer promotion; only the moving track owns the transform layer, reducing compositor memory and layer-management overhead.
* Pi 3-safe players use compositor Web Animations when available and cap only the requestAnimationFrame compatibility fallback to 30 updates per second.
* The Raspberry installer now activates `profile=pi3-safe`, bounds Firefox content/cache memory, prioritizes the kiosk modestly, and backgrounds the management agent without changing KMS, GPU drivers, hardware decoding, system services, clocks or voltage.

= 2.9.6 =
* Fixed a Raspberry Pi 3 black screen introduced by 2.9.5: the installer no longer forces KMS, Firefox WebRender/EGL/DMABUF, or Chromium GPU overrides. Raspberry Pi OS and the browser now select their tested graphics backend automatically.
* Re-running the installer removes only the KMS block written by 2.9.5, restoring the prior OS/display configuration while preserving the Pi 3 CPU, I/O, WiFi and background-service optimizations.
* Hardware H.264 decoding remains enabled as a preference, with automatic browser fallback when unavailable.
* Fixed the Pi 3 Infinite Slider becoming black when image playback began: removed size containment from the moving track and made low-power image content visible even while its motion dimensions are being measured.

= 2.9.5 =
* Added a Raspberry Pi 3 low-power player profile that removes expensive slider masks/shadows while retaining compositor-backed motion.
* Videos are now retained and preloaded as real media elements, then shown only after `canplay` (with a bounded fallback), preventing black/jumpy video transitions and ensuring slide time starts when content is actually visible.
* The Raspberry Pi installer now enables Firefox WebRender/EGL and hardware H.264 decoding instead of explicitly forcing software rendering and decoding.
* Added a safe, idempotent `optimize-pi.sh` for Pi 3: full KMS when unconfigured, performance CPU governor, WiFi power-save off, bounded volatile journals, conservative VM settings, and reversible removal of unrelated appliance services.
* Kiosk rendering receives higher CPU/I/O priority while the remote device agent runs at background priority. Chromium keeps shared-memory and shader acceleration rather than using the slower disk-backed rendering fallback.

= 2.9.4 =
* Connected screens now check a lightweight channel revision endpoint every second and fetch a fresh playlist immediately after a real channel or slide change.
* The normal full-playlist poll remains as a recovery path, while offline revision checks back off automatically and never overlap.
* Infinite Slider motion now uses compositor-backed Web Animations when supported, reducing main-thread work on Raspberry Pi and other low-powered players.
* Slider measurement waits for the complete first image sequence and coalesces image-load/resize work to prevent visible restarts and uneven motion.
* Custom-width images remain centered for Up, Down, Left and Right movement.

= 2.9.3 =
* Infinite Slider movement can now be set per channel to Auto, Up, Down, Left or Right. Existing Vertical and Horizontal settings migrate automatically to Up and Left.
* Added Full screen width or custom 10–100% screen-width sizing for Infinite Slider images while preserving image proportions.
* Down and Right use the same seamless continuous loop as Up and Left, including progress preservation after screen resizing.

= 2.9.2 =
* Infinite Slider orientation can now be set to Auto, Vertical or Horizontal per channel. Forced Vertical always uses one full-width column; forced Horizontal always uses one full-height row.
* Polished the signage-facing slider with restrained edge fading, stable image presentation and smoother continuous motion while keeping the screen free of controls or interface chrome.
* Slider progress is preserved across resize/orientation changes, delayed frames are clamped to prevent visible jumps, and reduced-motion preferences disable repetitive automatic movement.
* Reworked the channel's Infinite Slider settings into an accessible segmented orientation control and a cohesive settings card.

= 2.9.1 =
* Added **Infinite Slider** as a channel-level Slide transition for image-only zones. It continuously loops ordinary image slides in one vertical portrait column or one horizontal landscape row, with multiple images visible at once.
* Infinite Slider has separate portrait/landscape spacing, speed and image border-radius controls on the Channel edit page.
* Mixed-content zones preserve every slide by using normal Fade rotation when Infinite Slider is selected, rather than hiding unsupported content.
* Restored Infinite Scroll Gallery as a clearly separate multi-image slide type while keeping its existing saved content compatible.

= 2.9.0 =
* Transitions now belong to channels, so every slide in a channel uses one consistent transition instead of storing separate per-slide overrides.
* Infinite Scroll Gallery is now presented as Sliding carousel while retaining its original stored type for compatibility. Portrait zones use full-width images with adjustable vertical spacing; landscape zones use full-height images with adjustable horizontal spacing.
* Sliding carousels now render enough repeated image sequences to fill the screen continuously without blank gaps, including short galleries, and recalculate safely after screen resizing or orientation changes.
* Saving a slide without a name automatically creates the next available editable name such as `Slide 1` or `Slide 2`.

= 2.8.0 =
* New: `install-kiosk.sh --browser firefox` switches a Raspberry Pi kiosk from Chromium to Firefox ESR — a real alternative for a device where Chromium's translate popup (or other browser UI) keeps appearing despite every flag, policy and profile-level override already applied against it. Firefox has no equivalent auto-popping "translate this page?" prompt by default. Firefox gets its own `/etc/firefox/policies/policies.json` and a `user.js` in the kiosk profile disabling translations, telemetry, form/password saving, and other first-run prompts. `ds-agent`'s "Restart Browser" command now targets whichever browser is actually configured. Re-run with `--browser chromium` (or without `--browser`) to switch back — the choice persists across reboots either way.
* Also added a fourth, network-level layer against Chromium's translate popup for anyone staying on Chromium: `translate.google.com`/`translate.googleapis.com`/`translate-pa.googleapis.com` are now black-holed in `/etc/hosts`, so the feature can't reach Google's translate service regardless of whether the flags/policy/profile overrides are being honored.

= 2.7.4 =
* Raspberry Pi installer: added a third, independent layer against the Chromium translate popup — the kiosk profile's own `Preferences` file now gets `translate.enabled: false` merged in directly on every service start (not just once), so it applies even if the enterprise policy file or the `--disable-features` flag aren't being honored for some reason on a given Chromium build. Also added `--lang=en-US` to reduce the page/browser-language mismatches that trigger a translate offer in the first place.
* Audited the plugin's own JavaScript for anything that could cause an unexpected reload: confirmed there are only two conditional `window.location.reload()` calls in the entire codebase (the pairing screen reloading once a device is actually paired, and the player reloading on an explicit "Reload Browser Session" command from wp-admin) — nothing that could fire repeatedly on its own. A page that keeps reloading with neither of those happening is a Chromium-level issue (see 2.7.3's `/dev/shm` fix), not a plugin bug.

= 2.7.3 =
* Raspberry Pi installer: fixed the pairing/player page appearing to "refresh every few seconds" on the Pi specifically (worked fine on other devices) — a classic constrained-device Chromium issue where the renderer exhausts the default `/dev/shm` shared-memory pool, crashes, and `--kiosk` mode auto-reloads the page a few seconds later (the main browser process itself never restarts, which is why it wasn't visible as a crash in `journalctl`/the process list). Added `--disable-dev-shm-usage` so Chromium falls back to disk-backed temp storage instead. Also switched from `--incognito` (whole profile including cache held in RAM) to a small disk-backed profile at `/var/lib/digital-signage-kiosk-profile`, reducing memory pressure further. Re-run `install-kiosk.sh` to pick this up; `uninstall-kiosk.sh` now also cleans up that profile directory.

= 2.7.2 =
* An unpaired screen now generates a brand-new pairing code on every full page load (i.e. every boot/browser restart), instead of reusing whatever code was already on file for that device's token. Between full loads, the pairing screen's own JS still rotates it further every 30s as before (2.7.0). This also means that if a device's browser is reloading repeatedly for some other reason, the code shown at least always reflects the current one rather than looking stuck.

= 2.7.1 =
* Raspberry Pi installer now writes the Chromium anti-popup policy (translate, autofill, spellcheck, etc.) to both `/etc/chromium/policies/managed/` and `/etc/chromium-browser/policies/managed/` unconditionally, instead of guessing one from the installed package name — cheap insurance against a package/binary name mismatch across Raspberry Pi OS releases silently leaving the popup enabled. Re-run `install-kiosk.sh` to pick this up.

= 2.7.0 =
* Fixed pairing-code rotation not actually being visible: the polling endpoint now sends `nocache_headers()`, and the pairing screen's poll request uses `cache: 'no-store'` plus a cache-busting query param — without these, a host page cache or the browser's own HTTP cache could keep serving the exact same response on every poll, which looked exactly like rotation wasn't happening even though the server-side logic was correct.
* Rotation interval changed from 15s to 30s, and the pairing screen now shows a live "New code in Xs" countdown.
* Pairing screen text now sizes off viewport **width** by default (right for a normal TV and for a tall/narrow portrait screen), with a dedicated height-based override only for a short/wide bar display (e.g. 1920x440) where width-based sizing would overflow.
* `delete_screen()`'s pairing-code cleanup is now more robust — matches on both `screen_id` and the screen's pairing token, so a screen paired before this cleanup existed (or with an unset `screen_id`) still gets its code freed for reuse.
* New: **Scan QR Code** button on the "Pair a Screen" admin page — opens the camera and auto-fills the code once it reads the QR shown on the display, no typing needed. Uses the browser's built-in barcode detector (no external library), so the button only appears in browsers that support it (Chrome/Edge); everywhere else, typing the code in still works exactly as before.

= 2.6.0 =
* Fixed: deleting a screen now also frees its pairing code/token — previously the device's own persistent token stayed locked to an already-used code forever, so re-pairing the same physical device after deleting its screen was impossible ("invalid code") without manually clearing the database.
* Pairing codes now rotate every 15 seconds while unclaimed, swapped in place on the pairing screen (code + QR update live, no reload) — an old code left showing on an unattended screen stops working after 15s rather than staying valid indefinitely.
* Removed the "Tap anywhere for fullscreen" hint from the pairing screen entirely — it's still tried silently in the background for a normally-opened browser, but never shown as a prompt (a screen with no input device could never dismiss it anyway).
* Raspberry Pi installer now also writes a Chromium enterprise policy (`TranslateEnabled: false` and friends) disabling translate, autofill, spellcheck, notification/geolocation prompts, and other popups at the policy level — more reliable than command-line flags alone, which weren't fully suppressing the translate popup on some Chromium versions.
* New: the player shows "No channel selected" when a paired screen has no channel assigned (or nothing scheduled right now) instead of a blank/black screen that looked frozen or broken.
* Reworked the pairing screen and several player elements (clock, ticker, corner clock, start overlay) to size with `min(vw, vh)` instead of `vw` alone, so they scale correctly on extreme-aspect-ratio displays (a bar-shaped screen like 1920x440, or its portrait equivalent 440x1920) instead of overflowing or clipping.

= 2.5.0 =
* New: **Custom resolution** for Raspberry Pi kiosks with an uncommon or stretched display (e.g. a bar-shaped screen like 1920x440) that EDID auto-detection gets wrong. Set it up-front with `install-kiosk.sh --resolution WIDTHxHEIGHT`, or remotely from wp-admin (Screen edit page > Device > Custom resolution) — no SSH needed. Uses `cvt` to generate a matching display mode and applies it the same reliable way rotation does (restarting the kiosk service).
* New: **Recent activity log** on the Screen edit page's Device panel — `ds-agent`'s own log (commands applied, WiFi/rotation/resolution changes, errors) is now visible right in wp-admin, no SSH needed to see what a device has been doing.
* `ds-agent`'s heartbeat interval dropped from 30s to 10s, so WiFi/rotation/resolution/reboot/etc. commands queued in wp-admin get picked up faster.

= 2.4.6 =
* Fixed remote screen rotation (Screen edit page > Device > Screen rotation) not actually doing anything. Two bugs: (1) `ds-agent`'s own heartbeat call was overwriting the same database row the browser-based player heartbeats write to, including reporting its rotation setting into the column meant for the player's landscape/portrait viewport orientation — the two sources now only update the fields they actually own. (2) rotation was applied by asking the running X session to re-render live via a bare `xrandr` call from a separate systemd service with no X authentication context, which could silently fail; `ds-agent` now restarts `ds-kiosk.service` instead, reusing the exact rotation-apply code that already runs correctly on every normal boot. Update the plugin and re-run `install-kiosk.sh` (or just replace `ds-agent.py` and restart `ds-agent.service`) on each device to get the fix.

= 2.4.5 =
* The "Click to Start" / "Tap for fullscreen" prompts on the player and pairing screen no longer block playback forever on a screen with no input device. Previously they only got out of the way automatically for browsers launched with the installers' `?kiosk=1` URL flag — a screen still on an older `?kiosk=1`-less URL (plugin updated but the Pi/Windows installer not yet re-run) stayed stuck behind an unclickable overlay. Now both auto-dismiss after 4 seconds regardless, so updating the plugin alone fixes it even before you get around to re-running the installer on-device.

= 2.4.4 =
* Raspberry Pi and Windows kiosk installers now also pass `--disable-features=Translate,TranslateUI` to Chromium/Edge — the old `--disable-translate` flag they already had is legacy and no longer suppresses the "Translate this page?" popup on modern Chromium, which was showing up in the corner on kiosk screens.

= 2.4.3 =
* Kiosk devices (Raspberry Pi and Windows installers, both launching Chromium with `--kiosk`) no longer show a "Tap for fullscreen" / "Click to Start" prompt on the pairing screen or player — that prompt exists only for browsers opened normally, where the Fullscreen API needs a user gesture; a `--kiosk`-launched browser is already OS-level fullscreen with no chrome to hide, and a real kiosk has no mouse/touch/keyboard to click it with anyway. Both installers now open `?kiosk=1`, which the pairing and player pages detect and skip the prompt for entirely. Re-run the installer to pick this up — no `--regenerate` needed.

= 2.4.2 =
* Fixed the real cause of `install-kiosk.sh` silently dying before it ever created `ds-kiosk.service` (reported as "Unit ds-kiosk.service could not be found"): the device-token generation line (`tr ... | head -c 40`) tripped a classic `pipefail` + `head` interaction — `head` closes the pipe as soon as it has 40 bytes, `tr` gets `SIGPIPE`, and with `pipefail` on that counted as the whole pipeline failing even though the token came out correct, so `set -e` aborted the script right there with no error message. `pipefail` is now disabled for just that one line.

= 2.4.1 =
* Infinite Scroll Gallery: background color, image spacing and scroll speed are now set once per channel (new "Infinite Scroll Gallery defaults" section on the Channel edit page) instead of per slide, so every gallery slide in a channel shares the same look automatically.
* Raspberry Pi installer: `ds-kiosk.service` now runs as root and masks (not just disables) `getty@tty1.service` — the previous non-root/PAM-based approach could still fail to actually own the console on some systems. This removes that whole class of failure at the cost of Chromium needing `--no-sandbox` as root (already set), an acceptable trade for a dedicated single-purpose kiosk device.
* `uninstall-kiosk.sh` now removes everything installed (including `~/.xinitrc` and the pairing config) and fully restores console login.
* Expanded the Raspberry Pi README with a complete numbered install guide and manual `git clone`/`git pull` instructions.

= 2.4.0 =
* New slide type: **Infinite Scroll Gallery** — upload multiple images, set a background color and spacing between them, and they loop continuously with a configurable speed. Direction follows the screen's orientation automatically: top-to-bottom on portrait (images full width), left-to-right on landscape (images full height).
* Raspberry Pi installer: replaced the console-autologin + `~/.bash_profile` autostart mechanism with a `ds-kiosk.service` systemd unit that takes `tty1` directly and starts X — fixes installs that booted to a bare terminal instead of the kiosk on some Raspberry Pi OS builds where the login shell didn't reliably source `.bash_profile`. `install-kiosk.sh` cleans up the old mechanism automatically on re-run.

= 2.3.0 =
* New: remote Raspberry Pi device management. A screen running the new `ds-agent` (bundled with the Raspberry Pi kiosk installer) reports WiFi network/signal, CPU temperature, free disk space and rotation on every heartbeat, and a new "Device" panel on the Screen edit page can change its WiFi network, rotate the display, restart the browser, reboot, or check for updates — all remotely, no SSH needed.
* New `raspberry-pi-kiosk/setup-portal/`: a device with no configuration yet puts up a temporary WiFi hotspot with a one-page setup form (WiFi + site URL) instead of the kiosk — connect from a phone, submit, and it provisions itself and reboots into its pairing screen.
* New `pi-image-build/`: a `pi-gen` configuration plus a GitHub Actions workflow to build an actual flashable `.img` with all of the above pre-installed, for provisioning many screens at once.
* Database: added a `device_info` column to the heartbeats table (auto-migrated).

= 2.2.0 =
* Removed all byKUTT branding from the pairing/setup screen and admin footers — it now shows your own site name instead, so the product reads as one cohesive system rather than a watermarked template.
* Removed the now-unused logo asset.

= 2.1.2 =
* byKUTT logo is now plain white text (no gradient fill, no background), matching the pairing screen's dark backdrop; admin footers wrap it in a small dark chip so it stays visible there too.

= 2.1.1 =
* byKUTT logo is now just the animated-gradient wordmark (no background card), matching how it's used everywhere it appears.
* The unpaired-screen setup display now requests fullscreen on load too, with a tap-to-enable fallback, same as the player.

= 2.1.0 =
* Raspberry Pi and Windows kiosk installers now generate and persist the device's own pairing token, so the pairing code/identity survives every reboot without re-pairing.
* The unpaired-screen setup display now shows step-by-step instructions, a scan-to-pair QR code, and animated byKUTT branding.
* Images/video now fill the screen edge-to-edge by default (cropped to fit), with a per-slide "Fit: contain" option to letterbox instead, plus a per-channel background/letterbox color.
* Channel playlists show a thumbnail preview per slide instead of just a text row.
* Clock widget and admin timestamps now use 24-hour time and dd.mm.yyyy (Estonian) date formatting everywhere.
* Added a live "Preview" button on each channel (wp-admin-only, no screen/pairing required) and a Duplicate action for individual slides.
* Refined the admin visual design with slide-type icon illustrations and an onboarding "how it works" diagram.

= 2.0.0 =
* Replaced the WordPress native post-editor screens with a fully custom admin UI (dashboard, channel/screen/schedule list + edit pages, slide editor) — no more post.php/meta boxes.
* Fixed duplicate menu items and a capability bug that caused saves to redirect incorrectly.
* Simplified the admin menu; slides are managed from their owning channel instead of a separate tab.
* Added Raspberry Pi and Windows kiosk installers.

= 1.0.0 =
* Initial release.
